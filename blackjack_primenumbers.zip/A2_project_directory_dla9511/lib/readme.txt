Dependencies will be stored in this directory.

It's conventional to not store other people's code in your own GitHub repository so as to keep the repository focused on your own code. However, we have included these for simplicity in this repository so you don't have to worry about it:

- [junit v4.13.2.jar](https://search.maven.org/remotecontent?filepath=junit/junit/4.13.2/junit-4.13.2.jar)
- [hamcrest-core-1.3.jar](https://search.maven.org/remotecontent?filepath=org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar)
- [mockito-core-4.3.1.jar](https://repo1.maven.org/maven2/org/mockito/mockito-core/4.3.1/mockito-core-4.3.1.jar)
- [system-rules-1.19.0.jar](http://search.maven.org/remotecontent?filepath=com/github/stefanbirkner/system-rules/1.19.0/system-rules-1.19.0.jar)
